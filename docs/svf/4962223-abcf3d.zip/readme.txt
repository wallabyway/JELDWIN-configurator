
While the sample, you have used to get this content, is licensed under the terms of the MIT license, the content
people post on this site and the bubbles you can extract remain the property of their owner. For a good customer
experience the resulting ZIP file includes the current version of the viewer, but the intellectual property of this
component remains Autodesk's.

You can freely use it for offline viewing on your device, and/or use it on you website, but you cannot claim
it to be yours.
